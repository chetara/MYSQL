INSERT INTO `gta311-amcc-chea2613`.`d_employees`
(`FirstName`, `LastName`, `BirthDate`, `HireDate`, `Address`, `City`, `Region`, `PostalCode`, `Country`,
 `HomePhone`, `CellPhone`, `ReportTo`, `Salary`)
SELECT `FirstName`, `LastName`, `BirthDate`, `HireDate`, `Address`, `City`, `Region`, `PostalCode`, `Country`,
       `HomePhone`, `CellPhone`, `ReportsTo`, `Salary`
FROM `gta311-amcc-chea2613-e`.`src_amcc_employees`;


