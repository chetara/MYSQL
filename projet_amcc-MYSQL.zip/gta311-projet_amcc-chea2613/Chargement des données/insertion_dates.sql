USE `gta311-amcc-chea2613` ;
INSERT INTO `gta311-amcc-chea2613`.`d_dates` (`date`,`year`, `month`, `day`, `isWeekend`)
SELECT
	`src_amcc_dates`.`amcc_date`,
    YEAR(`amcc_date`) AS Year,
    MONTH(`amcc_date`) AS Month,
    DAY(`amcc_date`) AS Day,
    CASE WHEN WEEKDAY(`amcc_date`) IN (5, 6) THEN 1 ELSE 0 END AS IsWeekend
FROM
    `gta311-amcc-chea2613-e`.`src_amcc_dates`;