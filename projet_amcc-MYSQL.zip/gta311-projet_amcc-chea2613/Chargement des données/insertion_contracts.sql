insert into`gta311-amcc-chea2613`.`d_contracts`
    (`d_contracts`.`contractNumber`,
    `d_contracts`.`start_date`,
    `d_contracts`.`end_date`,
    `d_contracts`.`amount`,
    `d_contracts`.`signedBy`)
    (SELECT `src_amcc_contracts`.`contractNumber`,
    `src_amcc_contracts`.`start_date`,
    `src_amcc_contracts`.`end_date`,
    `src_amcc_contracts`.`amount`,
    `src_amcc_contracts`.`signedBy`
FROM `gta311-amcc-chea2613-e`.`src_amcc_contracts`);