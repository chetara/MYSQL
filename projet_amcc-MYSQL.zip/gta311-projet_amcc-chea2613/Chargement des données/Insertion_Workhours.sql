INSERT INTO `gta311-amcc-chea2613`.`f_workhours`
(`fk_contract`,
`fk_client`,
`fk_date`,
`fk_employee`,
`fk_role`,
`hours`,
`rate`,
`status`)
SELECT
`contractID`,
`ClientID`,
`dateID`,
`EmployeeID`,
`RoleID`,
-- Seules les heures travaillées doivent être additionnées lorsque des données sont en double, toutes les autres données en double doivent être éliminées.
SUM(`src_amcc_workhours`.`workhours_hours`),
`src_amcc_workhours`.`workhours_rate`,
-- Spécial c'est pour la valeur maximale
 IF(COUNT(*) > 1, 'Spécial', MAX(`src_amcc_workhours`.`workhours_status`)) 

 FROM  `gta311-amcc-chea2613-e`.`src_amcc_workhours`
     LEFT JOIN `gta311-amcc-chea2613`.`d_contracts`
    ON `d_contracts`.`contractNumber` = `src_amcc_workhours`.`contractNumber`
    LEFT JOIN `gta311-amcc-chea2613`.`d_clients`
    ON `src_amcc_workhours`.`Client_CompanyName` = `d_clients`.`CompanyName`
    LEFT JOIN `gta311-amcc-chea2613`.`d_dates`
    ON `src_amcc_workhours`.`workhours_date` = `d_dates`.`date`
    LEFT JOIN `gta311-amcc-chea2613`.`d_employees`
    ON CONCAT(`src_amcc_workhours`.`employee_firstname`,' ',`src_amcc_workhours`.`employee_lastname`)=CONCAT(`d_employees`.`FirstName`,' ', `d_employees`.`LastName`)
    LEFT JOIN `gta311-amcc-chea2613`.`d_roles`
    ON `src_amcc_workhours`.`employee_roleName` = `d_roles`.`roleName`
    
GROUP BY 
`src_amcc_workhours`.`workhours_date`,
   `src_amcc_workhours`.`employee_rate`,
   `d_contracts`.`contractID`,
   `d_clients`.`ClientID`,
   `d_dates`.`dateID`,
   `d_employees`.`EmployeeID`,
    `src_amcc_workhours`.`workhours_rate`,
   `d_roles`.`RoleID`;    
    
    


