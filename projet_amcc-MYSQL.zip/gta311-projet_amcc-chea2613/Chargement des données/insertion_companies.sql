


ALTER TABLE `gta311-amcc-chea2613`.`d_companies`
MODIFY COLUMN `Type` VARCHAR(10);


insert IGNORE into `gta311-amcc-chea2613`.`d_companies`  ( `d_companies`.`CompanyID`,
    `d_companies`.`CompanyName`,
    `d_companies`.`CEO`,
    `d_companies`.`Address`,
    `d_companies`.`City`,
    `d_companies`.`Region`,
    `d_companies`.`PostalCode`,
    `d_companies`.`country`,
    `d_companies`.`Type`,
    `d_companies`.`Size`,
    `d_companies`.`Description`,
    `d_companies`.`Note`) 
    (SELECT `src_amcc_companies`.`CompanyID`,
    `src_amcc_companies`.`CompanyName`,
    `src_amcc_companies`.`CEO`,
    `src_amcc_companies`.`Address`,
    `src_amcc_companies`.`City`,
    `src_amcc_companies`.`Region`,
    `src_amcc_companies`.`PostalCode`,
    `src_amcc_companies`.`Country`,
    null,
    `src_amcc_companies`.`Size`,
    `src_amcc_companies`.`Description`,
    `src_amcc_companies`.`Note`
FROM `gta311-amcc-chea2613-e`.`src_amcc_companies`);


update `gta311-amcc-chea2613`.`d_companies` set `d_companies`.`Type` =
case
when `d_companies`.`Size`<= 100 then 'SMB'
when `d_companies`.`Size` >= 1000 then 'LB'
else 'SME'
end ;

