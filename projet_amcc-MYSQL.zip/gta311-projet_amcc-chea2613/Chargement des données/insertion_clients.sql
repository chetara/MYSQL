insert into `gta311-amcc-chea2613`.`d_clients`(`CompanyName`,`CompanyUnit`,`ContactName`,`ContactTitle`,`Address`,`City`,
`Region`,`PostalCode`,`Country`,`Phone`,`Email`)
(SELECT `src_amcc_clients`.`CompanyName`,
    `src_amcc_clients`.`CompanyUnit`,
    `src_amcc_clients`.`ContactName`,
    `src_amcc_clients`.`ContactTitle`,
    `src_amcc_clients`.`Address`,
    `src_amcc_clients`.`City`,
    `src_amcc_clients`.`Region`,
    `src_amcc_clients`.`PostalCode`,
    `src_amcc_clients`.`Country`,
    `src_amcc_clients`.`Phone`,
    `src_amcc_clients`.`Email`
FROM `gta311-amcc-chea2613-e`.`src_amcc_clients`);
