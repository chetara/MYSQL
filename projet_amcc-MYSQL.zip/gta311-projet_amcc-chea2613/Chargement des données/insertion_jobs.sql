insert into `gta311-amcc-chea2613`.`d_roles` (`d_roles`.`roleName`,`d_roles`.`rank`,
`d_roles`.`rate`)
(SELECT `src_amcc_jobs`.`title`,
    `src_amcc_jobs`.`level`,
    `src_amcc_jobs`.`rate`
FROM `gta311-amcc-chea2613-e`.`src_amcc_jobs`);
