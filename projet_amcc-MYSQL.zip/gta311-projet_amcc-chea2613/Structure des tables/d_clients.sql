CREATE TABLE `gta311-amcc-chea2613`.`d_clients` (
  `ClientID` INT NOT NULL AUTO_INCREMENT,
  `CompanyName` VARCHAR(100) NOT NULL,
  `CompanyUnit` VARCHAR(100) NOT NULL,
  `ContactName` VARCHAR(100) NOT NULL,
  `ContactTitle` VARCHAR(30) NOT NULL,
  `Address` VARCHAR(100) NOT NULL,
  `City` VARCHAR(50) NOT NULL,
  `Region` VARCHAR(50) NOT NULL,
  `PostalCode` VARCHAR(10) NOT NULL,
  `Country` VARCHAR(50) NOT NULL,
  `Phone` VARCHAR(24) NOT NULL,
  `Email` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`ClientID`));

