CREATE TABLE IF NOT EXISTS `gta311-amcc-chea2613`.`d_companies` (
  `CompanyID` INT NOT NULL AUTO_INCREMENT,
  `CompanyName` VARCHAR(100) NOT NULL,
  `CEO` VARCHAR(100) NOT NULL,
  `Address` VARCHAR(100) NOT NULL,
  `City` VARCHAR(50) NOT NULL,
  `Region` VARCHAR(50) NOT NULL,
  `PostalCode` VARCHAR(10) NOT NULL,
  `country` VARCHAR(50) NOT NULL,
  `Type` VARCHAR(50),
  `Size` INT NOT NULL,
  `Description` VARCHAR(255) NULL,
  `Note` TEXT NULL,
  PRIMARY KEY (`CompanyID`));
  
 
ALTER TABLE `gta311-amcc-chea2613`.`d_companies` 
;
ALTER TABLE `gta311-amcc-chea2613`.`d_companies` ALTER INDEX `CompanyName_idx` VISIBLE, ALGORITHM = INPLACE;
