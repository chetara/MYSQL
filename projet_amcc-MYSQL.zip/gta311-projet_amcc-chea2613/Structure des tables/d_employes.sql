CREATE TABLE `gta311-amcc-chea2613`.`d_employees` (
  `EmployeeID` INT NOT NULL,
  `LastName` VARCHAR(100) NOT NULL,
  `FirstName` VARCHAR(100) NOT NULL,
  `BirthDate` DATETIME NOT NULL,
  `HireDate` DATETIME NOT NULL,
  `Address` VARCHAR(100) NOT NULL,
  `City` VARCHAR(25) NOT NULL,
  `Region` VARCHAR(25) NOT NULL,
  `PostalCode` VARCHAR(10) NOT NULL,
  `Country` VARCHAR(25) NOT NULL,
  `HomePhone` VARCHAR(24) NOT NULL,
  `CellPhone` VARCHAR(24) NOT NULL,
  `ReportTo` INT NULL,
  `Salary` DECIMAL(16,4) NOT NULL,
  PRIMARY KEY (`EmployeeID`) ) ;

ALTER TABLE `gta311-amcc-chea2613`.`d_employees` 
CHANGE COLUMN `EmployeeID` `EmployeeID` INT NOT NULL AUTO_INCREMENT ;

ALTER TABLE `gta311-amcc-chea2613`.`d_employees` 
ADD INDEX `ReportTo_idx` (`ReportTo` ASC) VISIBLE;
;
ALTER TABLE `gta311-amcc-chea2613`.`d_employees` 
ADD CONSTRAINT `ReportTo`
  FOREIGN KEY (`ReportTo`)
  REFERENCES `gta311-amcc-chea2613`.`d_employees` (`EmployeeID`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
