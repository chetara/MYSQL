CREATE TABLE `gta311-amcc-chea2613`.`d_dates` (
  `dateID` INT NOT NULL AUTO_INCREMENT,
  `date` DATE NOT NULL,
  `year` INT NOT NULL,
  `month` INT NOT NULL,
  `day` INT NOT NULL,
  `isWeekend` TINYINT NOT NULL,
  PRIMARY KEY (`dateID`));
