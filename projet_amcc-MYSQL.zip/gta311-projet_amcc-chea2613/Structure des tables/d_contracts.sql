CREATE TABLE `gta311-amcc-chea2613`.`d_contracts` (
  `contractID` INT NOT NULL AUTO_INCREMENT,
  `contractNumber` VARCHAR(45) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `amount` DECIMAL(16,4) NOT NULL,
  `signedBy` INT NOT NULL,
  PRIMARY KEY (`contractID`));
