-- Remplacer les valeurs vides par la valeur 'NA'
SELECT 
    `src_amcc_companies`.`Note`
FROM `gta311-amcc-chea2613-e`.`src_amcc_companies`;
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_companies` SET `src_amcc_companies`.`Note` = 'NA' WHERE `src_amcc_companies`.`Note` = '' ;


-- correction des données qui contient des caractères spésciaux
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_companies` SET `CompanyName` = 'CBC Radio-Canada' WHERE `CompanyName` = 'CBC/Radio-Canada' ;
