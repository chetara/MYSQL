USE `gta311-amcc-chea2613-e` ;
-- filtrer tous les date infèrier a la date '2018-01-01'
Select * FROM `gta311-amcc-chea2613-e`.`src_amcc_dates` 
WHERE `src_amcc_dates`.`amcc_date` < '2018-01-01' ;

-- correction des données
UPDATE `src_amcc_dates`
	SET `amcc_date` = '2018-01-01'
    WHERE `amcc_date` = '1998-01-01' ;
    
-- Filtrer les valeur Null 
Select * FROM `gta311-amcc-chea2613-e`.`src_amcc_dates` 
WHERE `src_amcc_dates`.`amcc_date` IS NULL;

