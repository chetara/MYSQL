-- Correction des nom et prénoms
ALTER TABLE `gta311-amcc-chea2613-e`.`src_amcc_employees`
CHANGE COLUMN `FirstName` `LastName` VARCHAR(100) NOT NULL ,
CHANGE COLUMN `LastName` `FirstName` VARCHAR(100) NOT NULL ;

-- Aprés une analyse visuelle de la table, j'ai remarque que toutes les dates 'birthdate' et 'hiredate' sont les memes. 
-- j'ai vérifié tous ces données dans le fichier dump et je les trouvés le memes. 
 -- je peux pas obtenir de données de référence fiables, je peux juste utiliser des valeurs par défaut pour les dates de naissance et de recrutement .
 -- J'ai choisis une date Arbitraire pour les deux colonnes  '2023-01-01'
 
 UPDATE `gta311-amcc-chea2613-e`.`src_amcc_employees`
SET
    `BirthDate` = '2023-01-01',
    `HireDate` = '2023-01-01';
    
    