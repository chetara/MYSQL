-- correction des données qui contient des caractères spésciaux pour résoudre le problème d'intégrété entre les deux tableau companies et clients

SELECT `src_amcc_clients`.`CompanyName` , `src_amcc_clients`.`ContactName` , `EMail`
FROM `gta311-amcc-chea2613-e`.`src_amcc_clients`
LEFT JOIN `gta311-amcc-chea2613-e`.`src_amcc_companies` ON `src_amcc_clients`.`CompanyName` = `src_amcc_companies`.`CompanyName`
WHERE `src_amcc_companies`.`CompanyName` IS NULL;

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'Lowe\'s Canada' WHERE `CompanyName` = 'Lowe\\\'s Canada';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`ContactName` = 'Sylvain Prud\'homme' WHERE `ContactName` = 'Sylvain Prud\\\'homme';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Email` = 'sylvain.prud\'homme@hotmail.com' WHERE `Email` = 'sylvain.prud\\\'homme@hotmail.com';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `CompanyName` = 'Société de l\'assurance automobile du Québec' WHERE `CompanyName` = 'Société de l\\\'assurance automobile du Québec' ; 

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'L\'Oréal Canada' WHERE `CompanyName` = 'L\\\'Oréal Canada';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'Société de transport de l\'Outaouais' WHERE `CompanyName` = 'Société de transport de l\\\'Outaouais';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'BCF Avocats d\'affaires' WHERE `CompanyName` = 'BCF Avocats d\\\'affaires';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'MTY (Groupe d\'Alimentation)'WHERE `CompanyName` = 'MTY (Groupe d\\\'Alimentation)';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'Fruit d\'Or'WHERE `CompanyName` = 'Fruit d\\\'Or';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'Société de l\'assurance automobile du Québec'WHERE `CompanyName` = 'Société de l\\\'assurance automobile du Québec';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`CompanyName` = 'CBC Radio-Canada' WHERE `CompanyName` = 'CBC/Radio-Canada';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`ContactName` = 'Alexandre L\'Heureux' WHERE `ContactName` = 'Alexandre L\\\'Heureux';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` = '2406 O\'Brien' WHERE `Address` = '2406 O\\\'Brien';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`ContactName` =  'Patrice L\'Huillier' WHERE `ContactName` =  'Patrice L\\\'Huillier';

UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` = '948 D\'Oxford Av' WHERE `Address` = '948 D\\\'Oxford Av';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` = '32 Av d\'Old Post Crescent' WHERE `Address` = '32 Av d\\\'Old Post Crescent';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` =  '8077 boul de l\'Acadie' WHERE `Address` = '8077 boul de l\\\'Acadie';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` =  '5236 Av de l\'Esplanade' WHERE `Address` = '5236 Av de l\\\'Esplanade';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` =  '3015 rg de L\'Ile' WHERE `Address` = '3015 rg de L\\\'Ile';
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Address` =  '5236 Av de l\'Esplanade' WHERE `Address` = '5236 Av de l\\\'Esplanade';


-- -- Remplacer les valeurs vides par la valeur 'NA'
SELECT `Phone`
FROM `gta311-amcc-chea2613-e`.`src_amcc_clients`;
UPDATE `gta311-amcc-chea2613-e`.`src_amcc_clients` SET `src_amcc_clients`.`Phone` = 'NA' WHERE `src_amcc_clients`.`Phone` = '' ;






