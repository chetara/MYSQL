-- Quelle est la période, en nombre de jours, couverte par les activités de consultation d’AMCC dans la base de données de démonstration ?
SELECT 
    MIN(`d_contracts`.`start_date`) AS date_debut,
    MAX(`d_contracts`.`end_date`) AS date_fin,
    DATEDIFF(MAX(`d_contracts`.`start_date`), MIN(`d_contracts`.`end_date`)) + 1 AS periode_enjours
FROM 
    `gta311-amcc-chea2613`.`f_workhours`

LEFT JOIN 
    `gta311-amcc-chea2613`.`d_contracts`
ON 
    `f_workhours`.`fk_contract` = `d_contracts`.`contractID`;

