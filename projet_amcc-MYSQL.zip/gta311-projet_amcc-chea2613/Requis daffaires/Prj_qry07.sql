-- Combien d’heures ont été travaillées les fins de semaine (week-end) chez AMCC ?

SELECT
    SUM(f.`hours`) AS TotalWeekendHours
FROM
    `gta311-amcc-chea2613`.`f_workhours` f
JOIN
    `gta311-amcc-chea2613`.`d_dates` d ON f.`fk_date` = d.`dateID`
WHERE
    d.`isWeekend` = 1;
