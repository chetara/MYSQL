SELECT
    `f_workhours`.`fk_role`,
    `d_roles`.`roleName`,
    COUNT(`f_workhours`.`hours`) AS TotalHours
FROM
    `gta311-amcc-chea2613`.`f_workhours`
JOIN `gta311-amcc-chea2613`.`d_roles`
ON `f_workhours`.`fk_role` = `d_roles`.`RoleID`
GROUP BY
    `f_workhours`.`fk_role`
ORDER BY
    TotalHours DESC;
