-- Prj-qry02 : Qui est le client le plus payant d’AMCC ?
-- je pris rate par rapport a une heuree
SELECT 
    `d_clients`.`ClientID`,
    `d_clients`.`CompanyName`,
    `d_clients`.`CompanyUnit`,
    `d_clients`.`ContactName`,
    `d_clients`.`ContactTitle`,
    `d_clients`.`Address`,
    `d_clients`.`City`,
    `d_clients`.`Region`,
    `d_clients`.`PostalCode`,
    `d_clients`.`Country`,
    `d_clients`.`Phone`,
    `d_clients`.`Email`,
    SUM(`f_workhours`.`hours` * `f_workhours`.`rate`) AS total_payment
FROM 
    `gta311-amcc-chea2613`.`f_workhours`
JOIN 
    `gta311-amcc-chea2613`.`d_clients`
ON 
    `f_workhours`.`fk_client` = `d_clients`.`ClientID`
GROUP BY 
    `d_clients`.`ClientID`,
    `d_clients`.`CompanyName`,
    `d_clients`.`CompanyUnit`,
    `d_clients`.`ContactName`,
    `d_clients`.`ContactTitle`,
    `d_clients`.`Address`,
    `d_clients`.`City`,
    `d_clients`.`Region`,
    `d_clients`.`PostalCode`,
    `d_clients`.`Country`,
    `d_clients`.`Phone`,
    `d_clients`.`Email`
ORDER BY 
    total_payment DESC
LIMIT 1;