-- Prj-qry05 : En moyenne, combien d’employés sont affectés à un contrat ?

SELECT 
	AVG(cnt) AS Moyenne_employé_affécté
FROM ( SELECT `f_workhours`.`fk_contract`,
COUNT( DISTINCT `f_workhours`.`fk_employee`) AS cnt 
FROM `gta311-amcc-chea2613`.`f_workhours` 
GROUP BY `f_workhours`.`fk_contract` ) AS A