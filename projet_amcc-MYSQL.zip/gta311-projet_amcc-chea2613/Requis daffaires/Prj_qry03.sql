-- Quel est l’employé d’AMCC ayant gagné le plus durant la période couverte par les données selon ses revenus liés à un contrat ?

SELECT
    e.EmployeeID,
    e.FirstName,
    e.LastName,
    SUM(w.hours * w.rate) AS TotalEarnings
FROM
    d_employees e
JOIN
    f_workhours w ON e.EmployeeID = w.fk_employee
JOIN
    d_contracts c ON w.fk_contract = c.contractID
WHERE
    c.start_date >= '2018-01-23'
    AND c.end_date <= '2021-12-13'
GROUP BY
    e.EmployeeID,
    e.FirstName,
    e.LastName
ORDER BY
    TotalEarnings DESC
LIMIT 1;
