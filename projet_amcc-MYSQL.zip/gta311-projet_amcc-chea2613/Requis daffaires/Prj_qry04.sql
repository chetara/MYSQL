SELECT 
    `d_clients`.`CompanyName`,
    COUNT(`d_clients`.`CompanyUnit`) AS cnt
FROM `gta311-amcc-chea2613`.`d_clients`
GROUP BY `d_clients`.`CompanyName`
ORDER BY cnt DESC;
